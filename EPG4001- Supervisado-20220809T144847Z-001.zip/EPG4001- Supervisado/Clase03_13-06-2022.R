#############################
## Ejemplo

library(faraway)

?ozone
head(ozone)
names(ozone)

plot(faraway::ozone)

## VIF

?vif
vif(ozone[,-1])
vif(ozone[,-c(1,8)])

round(cor(ozone[,-1]),2)

det(t(as.matrix(ozone[,-1]))%*%as.matrix(ozone[,-1]))^(-1)

## Modelos de regresión

 summary(lm(O3~., data=ozone))
 reg1=step(lm(O3~., data=ozone))
 reg2=step(lm(O3~., data=ozone[,-8]))

 summary(reg1)
 summary(reg2)  

 AIC(reg1)
 AIC(reg2)
 
# Diagnostico
 
 shapiro.test(reg1$residuals)
 shapiro.test(reg2$residuals)
 
 qqnorm(reg1$residuals, pch=20); qqline(reg1$residuals, col=2, lwd=2)
 qqnorm(reg2$residuals, pch=20); qqline(reg2$residuals, col=2, lwd=2)

 qqnorm(ozone$O3)
 
## Ejemplo bernoulli

?faraway::wcgs
head(faraway::wcgs)
summary(faraway::wcgs)

log1=glm(chd~cigs, data=wcgs, family=binomial )
log1
summary(log1)

log2=glm(chd~., data=wcgs, family=binomial )
step(log2)
summary(log2)

log1$fitted.values


















