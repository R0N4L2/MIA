#############################################################
## Ejemplo1: Regresión

## Ingresar datos manuelmante

 x=c( 11, 14, 16, 15, 16, 18, 20, 21, 14, 20, 19, 11)
 y=c( 2, 3, 5, 6, 5, 3, 7, 10, 6, 10, 5, 6)
 datos=data.frame(Inv=x, Rend=y)
 
 x.pred=data.frame(Inv=seq(min(x), max(x), by=0.005))

## Resumen descriptivo 
 summary(datos) 
 plot(Rend~Inv, data=datos, pch=20)
 
 png(filename="ejemplo1_inv-rend.png", width=768, height=512, res=120)
 plot(Rend~Inv, data=datos, pch=20, main="Inversión vs. Rendimiento")
 dev.off()
 
## Regresión: Lineal vs k-nn
 
 reg1=lm(Rend~Inv, data=datos)
 reg2=lm(Rend~Inv+I(Inv^2), data=datos)

 pred.reg1=predict(reg1, x.pred)
 pred.reg2=predict(reg2, x.pred)
 
 knn1 <- caret::knnreg(Rend~Inv, data=datos, k = 1)
 knn2 <- caret::knnreg(Rend~Inv, data=datos, k = 6)
 
 pred.knn1=predict(knn1, x.pred)
 pred.knn2=predict(knn2, x.pred)
 
 x.pred$Inv[c(201,1201)]
 
 print(xtable::xtable(cbind(
 Inversion=x.pred$Inv[c(201,1201)],
 Pred.Lineal=pred.reg1[c(201,1201)],
 Pred.Cuadratico=pred.reg2[c(201,1201)],
 Pred.1NN=pred.knn1[c(201,1201)],
 Pred.6NN=pred.knn2[c(201,1201)])), booktabs=TRUE, include.rownames=FALSE)
 
## Grafica: Lineal vs k-nn
 
 png(filename="ejemplo2_inv-rend.png", width=768, height=512, res=120)
  plot(Rend~Inv, data=datos, pch=20, main="Inversión vs. Rendimiento")
  points(x.pred$Inv, pred.reg1, type="l", col=2, lty=1, lwd=2) 
  points(x.pred$Inv, pred.reg2, type="l", col=3, lty=1, lwd=2) 
  points(x.pred$Inv, pred.knn1, type="l", col=4, lty=1, lwd=2)
  points(x.pred$Inv, pred.knn2, type="l", col=5, lty=1, lwd=2)
  legend("topleft", legend=c("Lineal","Cuadratico", "1-NN", "6-NN"),
        lty=1, lwd=2, inset = 0.01, col=2:5, bg="gray80"  )
  points(x.pred$Inv[c(201,1201)], pred.reg1[c(201,1201)], col=2, pch=20, cex=1.2) 
  points(x.pred$Inv[c(201,1201)], pred.reg2[c(201,1201)], col=3, pch=20, cex=1.2) 
  points(x.pred$Inv[c(201,1201)], pred.knn1[c(201,1201)], col=4, pch=20, cex=1.2)
  points(x.pred$Inv[c(201,1201)], pred.knn2[c(201,1201)], col=5, pch=20, cex=1.2)
 dev.off() 
 
#######################################################
### Ejemplo2: Clasificación
 
### Cargar Librerias 
 
 library(MASS)  # permite simular desde una normal multivariada
 library(class) # permite ejecutar el k-NN.
 
### Definición de Grupos
 
 mu1=c(1,1);  sigma1=diag(c(0.2,0.1));  n1=200
 mu2=c(0,0);  sigma2=diag(c(0.3,0.3));  n2=300
 mu3=c(1,-1); sigma3=diag(c(0.1,0.2));  n3=250
 
 g1=mvrnorm(n1,mu1,sigma1)
 g2=mvrnorm(n2,mu2,sigma2)
 g3=mvrnorm(n3,mu3,sigma3)
 

### Unir los grupos para crear una base de datos
 
 data=rbind(cbind(g1,1), cbind(g2,2), cbind(g3,3))
 dim(data)
 head(data)

 plot(g1, xlim=c(-2.5,4), ylim=c(-6,6), col=2, pch="1")
 points(g2, col=3, pch="2")
 points(g3, col=4, pch="3")
 points(0,0, col=1, pch="1", lwd=5, cex=2)
 points(1,1, col=1, pch="2", lwd=5, cex=2)
 points(1,-1, col=1, pch="3", lwd=5, cex=2)
 
#### Metodo 1: Matriz Indicadora (regresion lineal)
 
 Y=matrix(0,nc=3,nr=nrow(g1)+nrow(g2)+nrow(g3))
 Y[data[,3]==1,1]<-1
 Y[data[,3]==2,2]<-1
 Y[data[,3]==3,3]<-1
 X=cbind(1,data[,1:2])
 dim(X); dim(Y)
 (B=solve(t(X)%*%X)%*%t(X)%*%Y)
 
 (lm1=lm(Y~.,as.data.frame(data[,1:2])))
 
 x=expand.grid(seq(-2,4,by=0.1),seq(-6,6,by=0.1))
 x0=as.matrix(cbind(1,x))
 pred=apply(x0%*%B,1,which.max)
 apply(x0%*%B,1,sum)
 
 plot(g1, xlim=c(-2,3), ylim=c(-3,3), col=2, pch="1", xlab="X1", ylab="X2")
 points(g2, col=3, pch="2")
 points(g3, col=4, pch="3")
 points(x0[pred==1,2:3], col=2, pch=20, cex=0.75)
 points(x0[pred==2,2:3], col=3, pch=20, cex=0.75)
 points(x0[pred==3,2:3], col=4, pch=20, cex=0.75)
 
#### Metodo 2: k-NN
 
 knn1=knn(data[,1:2], x0[,2:3], data[,3], k = 1, prob=TRUE)
 knn2=knn(data[,1:2], x0[,2:3], data[,3], k = 10, prob=TRUE)
 knn3=knn(data[,1:2], x0[,2:3], data[,3], k = 100, prob=TRUE)
 
 plot(g1, xlim=c(-2,3), ylim=c(-3,3), col=2, pch="1", xlab="X1", ylab="X2")
 points(g2, col=3, pch="2")
 points(g3, col=4, pch="3")
 points(x0[knn1==1,2:3], col=2, pch=20, cex=0.75)
 points(x0[knn1==2,2:3], col=3, pch=20, cex=0.75)
 points(x0[knn1==3,2:3], col=4, pch=20, cex=0.75)
 
 plot(g1, xlim=c(-2,3), ylim=c(-3,3), col=2, pch="1", xlab="X1", ylab="X2")
 points(g2, col=3, pch="2")
 points(g3, col=4, pch="3")
 points(x0[knn2==1,2:3], col=2, pch=20, cex=0.75)
 points(x0[knn2==2,2:3], col=3, pch=20, cex=0.75)
 points(x0[knn2==3,2:3], col=4, pch=20, cex=0.75)
 
 plot(g1, xlim=c(-2,3), ylim=c(-3,3), col=2, pch="1", xlab="X1", ylab="X2")
 points(g2, col=3, pch="2")
 points(g3, col=4, pch="3")
 points(x0[knn3==1,2:3], col=2, pch=20, cex=0.75)
 points(x0[knn3==2,2:3], col=3, pch=20, cex=0.75)
 points(x0[knn3==3,2:3], col=4, pch=20, cex=0.75)
 

  