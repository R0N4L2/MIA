library(faraway)
install.packages("faraway")


x=c(1,3,5,10)
x=1:10
x=seq(0,1,by=0.1)
x

X=data.frame(x1=1:10, x2=seq(0,1, l=10), x3=rnorm(10))
X
X$x1
X$x2
X[[3]]
X$x1[c(3,8)]
X$x1[-3]


#############################
## Ejemplo

?ozone
head(ozone)
names(ozone)

plot(faraway::ozone)

mod1=lm(O3~., data=ozone)
mod2=lm(O3~wind+temp+humidity, data=ozone)
mod1
mod2
summary(mod1)
summary(mod2)

?step
mod1.step=step(mod1)
mod1.step2=step(mod1, k=log(length(ozone$O3)))
mod1.step3=step(mod2, scope=list(lower=mod2, upper=mod1), direction="both")

summary(mod1.step)
summary(mod1.step2)

