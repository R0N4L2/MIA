#############################################
## librerias requeriadas

library(faraway)
library(caret)
library(splitTools)
library(DAAG)

#############################################
## Ejemplo de simulación en Regresión

## Ejemplo de simulación para analizar como funciona la validación cruzada k-fold

# y=f(x)+error

n=1000
set.seed(0)
x=round(runif(n),2)
set.seed(1)
error=rnorm(n,0,0.2)
y=round(1-x+2*x^2+error,2) # función escogida: f(x)=1-x+2x^2

plot(y~x, pch=20, col="black")

datos=data.frame(x=x, y=y)
head(datos)

## Separación test - train

set.seed(2)
ind_train <- partition(1:nrow(datos), p=c(0.8, 0.2))
data.train <- datos[ind_train$`1`,]
data.test <- datos[ind_train$`2`,]


plot(y~x, pch=20, col="gray", data=data.train)
points(y~x, pch=20, col="red", data=data.test)

## Validación cruzada
# K fold, k=3

set.seed(3)
aux2=sample.int(800,800) # se realiza una permutación aleatoria

part1=aux2[1:267]    # se seleccionan las filas de la primera particion
part2=aux2[268:534]  # se seleccionan las filas de la segunda particion
part3=aux2[535:800]  # se seleccionan las filas de la tercera particion

## Modelo 1: f(x)=b0+b1*x

mod1.part1=lm(y~x, data=data.train[-part1,]) 
mod1.part2=lm(y~x, data=data.train[-part2,])
mod1.part3=lm(y~x, data=data.train[-part3,])

## Modelo 2: f(x)=b0+b1*x+b2*x^2

mod2.part1=lm(y~poly(x,2, raw=TRUE), data=data.train[-part1,])
mod2.part2=lm(y~poly(x,2, raw=TRUE), data=data.train[-part2,])
mod2.part3=lm(y~poly(x,2, raw=TRUE), data=data.train[-part3,])

## Modelo 3: f(x)=b0+b1*x^2

mod3.part1=lm(y~I(x^2), data=data.train[-part1,])  
mod3.part2=lm(y~I(x^2), data=data.train[-part2,])
mod3.part3=lm(y~I(x^2), data=data.train[-part3,])

## Modelo 4: f(x)=b0+b1*x+b2*x^2+b3*x^3+b4*x^4+b5*x^5

mod4.part1=lm(y~poly(x,5, raw=TRUE), data=data.train[-part1,])  
mod4.part2=lm(y~poly(x,5, raw=TRUE), data=data.train[-part2,])
mod4.part3=lm(y~poly(x,5, raw=TRUE), data=data.train[-part3,])

########################################################
## Medida de Error en las predicciones por carpeta

pred1.part1=predict(mod1.part1, data.train[part1,])
pred1.part2=predict(mod1.part2, data.train[part2,])
pred1.part3=predict(mod1.part3, data.train[part3,])

pred2.part1=predict(mod2.part1, data.train[part1,])
pred2.part2=predict(mod2.part2, data.train[part2,])
pred2.part3=predict(mod2.part3, data.train[part3,])

pred3.part1=predict(mod3.part1, data.train[part1,])
pred3.part2=predict(mod3.part2, data.train[part2,])
pred3.part3=predict(mod3.part3, data.train[part3,])

pred4.part1=predict(mod4.part1, data.train[part1,])
pred4.part2=predict(mod4.part2, data.train[part2,])
pred4.part3=predict(mod4.part3, data.train[part3,])

(rsme1=c(sqrt(mean((data.train[part1,2]-pred1.part1)^2)),
        sqrt(mean((data.train[part2,2]-pred1.part2)^2)),
        sqrt(mean((data.train[part3,2]-pred1.part3)^2))) )

(rsme2=c(sqrt(mean((data.train[part1,2]-pred2.part1)^2)),
        sqrt(mean((data.train[part2,2]-pred2.part2)^2)),
        sqrt(mean((data.train[part3,2]-pred2.part3)^2))) )

(rsme3=c(sqrt(mean((data.train[part1,2]-pred3.part1)^2)),
        sqrt(mean((data.train[part2,2]-pred3.part2)^2)),
        sqrt(mean((data.train[part3,2]-pred3.part3)^2))))

(rsme4=c(sqrt(mean((data.train[part1,2]-pred4.part1)^2)),
        sqrt(mean((data.train[part2,2]-pred4.part2)^2)),
        sqrt(mean((data.train[part3,2]-pred4.part3)^2))) )


mean(rsme1); mean(rsme2); mean(rsme3); mean(rsme4) # el mejor es modelo 2,
# coincide con modelo simulado, pero puede ser que al cambiar los números aleatorios otro modelo puede ser el mejor

######################################################################
## Rendimiento del modelo seleccionado

## En teoría solo se evalua el rendimiento del modelo seleccionado, pero a modo comparativo se evaluaran los otros 3 modelos

(mod1=lm(y~x, data=data.train))
(mod2=lm(y~poly(x,2, raw=TRUE), data=data.train))
(mod3=lm(y~I(x^2), data=data.train))
(mod4=lm(y~poly(x,5, raw=TRUE), data=data.train))

pred1=predict(mod1, data.test)
pred2=predict(mod2, data.test)
pred3=predict(mod3, data.test)
pred4=predict(mod4, data.test)

sqrt(mean((data.test[,2]-pred1)^2))
sqrt(mean((data.test[,2]-pred2)^2)) 
sqrt(mean((data.test[,2]-pred3)^2))
sqrt(mean((data.test[,2]-pred4)^2))

plot(y~x, pch=20, col="gray", data=data.train)
points(y~x, pch=20, col="red", data=data.test)
abline(mod1, lwd=2, col="blue")
x0=seq(-0.1,1.1,by=0.01)
lines(x0, predict(mod2, data.frame(x=x0)), lwd=2, col="green")
lines(x0, predict(mod3, data.frame(x=x0)), lwd=2, col="orange")
lines(x0, predict(mod4, data.frame(x=x0)), lwd=2, col="violet")

# Obs: Repetir lo anterior muchas veces y notar si se estabiliza el resultado.


#####################################
## K-fold en libreria caret

 modelos=list(y~x, y~poly(x,2, raw=TRUE), y~I(x^2),  y~poly(x,5, raw=TRUE))

 result.model=list()
 for(i in 1:length(modelos)){
   result.model[[i]] <- train(modelos[[i]], data=data.train, 
                   trControl=trainControl(method="cv", number=3),
                   method="lm")
   print(result.model[[i]]$results)
 }

 # A nivel de Predicciones
 sqrt(mean((data.test[,2]-pred2)^2))       
 sqrt(mean((data.test[,2]- predict(result.model[[2]], data.test))^2))


###############################################
## Ejercicio 1: Predicir el O3 de la data Ozone

## Train-Test para Regresión

 ?ozone
 summary(ozone)
 plot(ozone)

## Separar la data en train y test

 set.seed(0)
 ind_train <- partition(1:nrow(ozone), p=c(0.7, 0.3))
 train <- data[ind_train$`1`,]
 test <- data[ind_train$`2`,]
 
 summary(train)
  

###############################################
## Ejemplo para Clasificación
 
 library(DAAG)
 
 data<-spam7
 summary(data)
 data$yesno<-factor(data$yesno)
 
 ind_train <- partition(1:nrow(data), p=c(0.7, 0.3))
 train <- data[ind_train$`1`,]
 test <- data[ind_train$`2`,]
 
 head(train)
 head(test)
 
 train.control_lgocv_c <- trainControl(method = "cv", number = 10)

 #Se especifican algunos modelos
 
 model1_cv_class <- train(yesno ~., data = train, method = "glm", trControl = train.control_lgocv_c)
 model2_cv_class <- train(yesno ~ dollar+bang, data = train, method = "glm", trControl = train.control_lgocv_c)
 
 model1_cv_class$resample
 model2_cv_class$resample
 
 model1_cv_class$results #Resultados resumidos # mejor modelo1
 model2_cv_class$results #Resultados resumidos
 
 mod1=glm(yesno~., data=train, family=binomial)
 
 pred.prob=predict(mod1, test, type="response")
 pred.class=ifelse(pred.prob>0.5, "y", "n")
 
 table(test$yesno, pred.class)
 
###################################################################
## Ejercicio 2: Mejorar el modelo de clasificación para spam 
 
 
  
 
 
 