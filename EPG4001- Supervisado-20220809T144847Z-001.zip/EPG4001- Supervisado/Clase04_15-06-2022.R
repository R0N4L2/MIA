## Ejemplo binomial: Venables and Ripley (2002, pp. 190-2.)

 ldose <- rep(0:5, 2)
 numdead <- c(1, 4, 9, 13, 18, 20, 0, 2, 6, 10, 12, 16)
 sex <- factor(rep(c("M", "F"), c(6, 6)))
 SF <- cbind(numdead, numalive = 20-numdead)
 data.frame(SF, sex, ldose)

 interaction.plot(ldose, sex, SF[,"numdead"])
 interaction.plot(ldose, sex, SF[,2])

 mod1.binom <- glm(SF ~ sex*ldose, family = binomial)
 summary(mod1.binom)
 anova(mod1.binom, test="LR")
 anova(glm(SF ~ ldose*sex, family = binomial), test="LR")
 car::Anova(mod1.binom, test="LR", type="III")

 mod2.binom <- glm(SF ~ sex+ldose, family = binomial)
 anova(mod2.binom, test="Chisq")
 car::Anova(mod2.binom, test="LR", type="II")

 mod3.binom <- step(mod1.binom) # AIC y Deviance detectan el mismo modelo.
 
## Residuos

 res1.binom=residuals(mod1.binom) # Deviance
 res2.binom=residuals(mod2.binom) # Deviance

 qqnorm(res1.binom, pch=20); qqline(res1.binom, col=2)
 qqnorm(res2.binom, pch=20); qqline(res2.binom, col=2)
 
 shapiro.test(res1.binom)
 shapiro.test(res2.binom)

 plot(mod1.binom)
 plot(mod2.binom)
 
## Predicciones

 ld <- seq(0, 5, 0.1)
 (x.pred=expand.grid(ldose=ld, sex=factor(c("F", "M"))) )

 pred1.resp=predict(mod1.binom, x.pred, type = "response")
 pred2.resp=predict(mod2.binom, x.pred, type = "response") # Modelo adecuado

 head(cbind(pred1.resp,pred2.resp),5)
 
 head(cbind(pred2.resp, predict(mod2.binom, x.pred, type = "link")), 5) 
 
 plot(c(1,5), c(0,1), type = "n", xlab = "dose", ylab = "prob", main="Probability of Dead")
 lines(ld, pred1.resp[x.pred$sex=="F"], col=2, lty=2, lwd=1.5)
 lines(ld, pred1.resp[x.pred$sex=="M"], col=4, lty=2, lwd=1.5)
 
 lines(ld, pred2.resp[x.pred$sex=="F"], col=2, lty=1, lwd=1.5)
 lines(ld, pred2.resp[x.pred$sex=="M"], col=4, lty=1, lwd=1.5)
 points(ldose, numdead/20, pch=20, cex=0.5)
 text(ldose, numdead/20, as.character(sex), col=rep(c(4,2), each=6))
 abline(h=0.5, lty=2, col=1)

## Otros Modelos posibles: Cambiar la función de enlace
 
 mod4.binom <- glm(SF ~ sex+ldose, family = binomial(link="probit"))
 mod5.binom <- glm(SF ~ sex+ldose, family = binomial(link="cloglog")) 

 car::Anova(mod4.binom, type="II", test="LR") 
 car::Anova(mod5.binom, type="II", test="LR") 
 
 plot(mod4.binom)
 plot(mod5.binom)

 pred4.resp=predict(mod4.binom, x.pred, type = "response")
 pred5.resp=predict(mod4.binom, x.pred, type = "response")  
 
 plot(c(1,5), c(0,1), type = "n", xlab = "dose", ylab = "prob", main="Probability of Dead")
 lines(ld, pred2.resp[x.pred$sex=="F"], col=2, lty=1, lwd=1.5)
 lines(ld, pred2.resp[x.pred$sex=="M"], col=4, lty=1, lwd=1.5)
 
 lines(ld, pred4.resp[x.pred$sex=="F"], col=2, lty=2, lwd=1.5)
 lines(ld, pred4.resp[x.pred$sex=="M"], col=4, lty=2, lwd=1.5)
 
 lines(ld, pred5.resp[x.pred$sex=="F"], col=2, lty=3, lwd=1.5)
 lines(ld, pred5.resp[x.pred$sex=="M"], col=4, lty=3, lwd=1.5)
 
 points(ldose, numdead/20, pch=20, cex=0.5)
 text(ldose, numdead/20, as.character(sex), col=rep(c(4,2), each=6))
 abline(h=0.5, lty=2, col=1)
 
## Otros Modelos posibles: Agregar un parametro de sobredispersión
 
 mod6.binom <- glm(SF ~ sex+ldose, family = quasibinomial)
 mod7.binom <- glm(SF ~ sex+ldose, family = quasibinomial(link="probit"))
 mod8.binom <- glm(SF ~ sex+ldose, family = quasibinomial(link="cloglog")) 
 
 summary(mod6.binom)
 summary(mod7.binom)
 summary(mod8.binom)

 car::Anova(mod6.binom, type="II", test="LR") 
 car::Anova(mod7.binom, type="II", test="LR") 
 car::Anova(mod8.binom, type="II", test="LR")   
 
 plot(mod4.binom)
 plot(mod5.binom)
 plot(mod6.binom)
 
 pred6.resp=predict(mod6.binom, x.pred, type = "response")
 pred7.resp=predict(mod7.binom, x.pred, type = "response")  
 pred8.resp=predict(mod8.binom, x.pred, type = "response")
 
 plot(c(1,5), c(0,1), type = "n", xlab = "dose", ylab = "prob", main="Probability of Dead")
 lines(ld, pred2.resp[x.pred$sex=="F"], col=2, lty=1, lwd=1.5)
 lines(ld, pred2.resp[x.pred$sex=="M"], col=4, lty=1, lwd=1.5)
 
 lines(ld, pred6.resp[x.pred$sex=="F"], col=2, lty=2, lwd=2.5)
 lines(ld, pred6.resp[x.pred$sex=="M"], col=4, lty=2, lwd=2.5)
 points(ldose, numdead/20, pch=20, cex=0.5)
 text(ldose, numdead/20, as.character(sex), col=rep(c(4,2), each=6))
 abline(h=0.5, lty=2, col=1)
 
 
 plot(c(1,5), c(0,1), type = "n", xlab = "dose", ylab = "prob", main="Probability of Dead")
 lines(ld, pred4.resp[x.pred$sex=="F"], col=2, lty=1, lwd=1.5)
 lines(ld, pred4.resp[x.pred$sex=="M"], col=4, lty=1, lwd=1.5)
 
 lines(ld, pred7.resp[x.pred$sex=="F"], col=2, lty=2, lwd=2.5)
 lines(ld, pred7.resp[x.pred$sex=="M"], col=4, lty=2, lwd=2.5)
 points(ldose, numdead/20, pch=20, cex=0.5)
 text(ldose, numdead/20, as.character(sex), col=rep(c(4,2), each=6))
 abline(h=0.5, lty=2, col=1)
 
 plot(c(1,5), c(0,1), type = "n", xlab = "dose", ylab = "prob", main="Probability of Dead")
 lines(ld, pred5.resp[x.pred$sex=="F"], col=2, lty=1, lwd=1.5)
 lines(ld, pred5.resp[x.pred$sex=="M"], col=4, lty=1, lwd=1.5)
 
 lines(ld, pred8.resp[x.pred$sex=="F"], col=2, lty=2, lwd=2.5)
 lines(ld, pred8.resp[x.pred$sex=="M"], col=4, lty=2, lwd=2.5)
 points(ldose, numdead/20, pch=20, cex=0.5)
 text(ldose, numdead/20, as.character(sex), col=rep(c(4,2), each=6))
 abline(h=0.5, lty=2, col=1)
 
### Predicciones con Intervalos de confianza
 
 pred.resp=predict(mod2.binom, x.pred, type = "response", se.fit=TRUE)
 pred.link=predict(mod2.binom, x.pred, type = "link", se.fit=TRUE)
 
 confint(mod2.binom, level=0.95)
 confint.default(mod2.binom, level=0.95)  #normalidad asintótica
 
 cbind(pred.resp$fit, exp(pred.link$fit)/(1+exp(pred.link$fit)))
 
 LI1=pred.resp$fit-qnorm(0.975)*pred.resp$se.fit
 LS1=pred.resp$fit+qnorm(0.975)*pred.resp$se.fit
 
 aux.LI2=pred.link$fit-qnorm(0.975)*pred.link$se.fit
 aux.LS2=pred.link$fit+qnorm(0.975)*pred.link$se.fit
 
 LI2=exp(aux.LI2)/(1+exp(aux.LI2))
 LS2=exp(aux.LS2)/(1+exp(aux.LS2))

 min(LI1); min(LI2)
 max(LS1); max(LS2)
 
 xx0=c(ld, rev(ld))
 yyF1=c(LI1[x.pred$sex=="F"], rev(LS1[x.pred$sex=="F"]))
 yyM1=c(LI1[x.pred$sex=="M"], rev(LS1[x.pred$sex=="M"]))
 
 yyF2=c(LI2[x.pred$sex=="F"], rev(LS2[x.pred$sex=="F"]))
 yyM2=c(LI2[x.pred$sex=="M"], rev(LS2[x.pred$sex=="M"]))
 
 plot(c(1,5), c(0,1), type = "n", xlab = "dose", ylab = "prob", main="Probability of Dead")
 lines(ld, pred.resp$fit[x.pred$sex=="F"], col=2, lty=1, lwd=1.5)
 lines(ld, pred.resp$fit[x.pred$sex=="M"], col=4, lty=1, lwd=1.5)
 polygon(xx0, yyM1, border=8, col=topo.colors(10, alpha=0.1 ) ) 
 polygon(xx0, yyF1, border=8, col=heat.colors(10, alpha=0.1 ) )
 polygon(xx0, yyM2, border=8, col=topo.colors(10, alpha=0.1 ) ) 
 polygon(xx0, yyF2, border=8, col=heat.colors(10, alpha=0.1 ) )
 text(ldose, numdead/20, as.character(sex), col=rep(c(4,2), each=6))
 abline(h=0.5, lty=2, col=1)
 
  