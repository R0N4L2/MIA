##############################################
## librerias requeriadas

library(caret)
library(splitTools)
library(DAAG)
library(MASS)
library(naivebayes)
library(Metrics)

##############################################
## Ejemplo: Matriz de Confusion

lvs <- c("A", "B")
real <- factor(rep(lvs, times = c(86, 258)) )
pred <- factor(rep(c(lvs,lvs), times = c(50, 36, 58, 200)) )


table(real, pred)  # se considera la clase "n" como objetivo
confusion(real, pred)

confusionMatrix(pred, real)
confusionMatrix(pred, real, mode="prec_recall")
confusionMatrix(pred, real, mode="everything")

confusionMatrix(pred, real, mode="everything", positive="B")

F_meas(pred, real)
F_meas(pred, real, beta=2)

F_meas(pred, real, relevant="B")
F_meas(pred, real, beta=2, relevant="B")

accuracy(real, pred)

##############################################
## Definición de las data de trabajo

 ?spam7
 head(spam7)
 summary(spam7)
 
 class(spam7)
 str(spam7)
 sum(as.integer(spam7$crl.tot)!=spam7$crl.tot)
 spam7$crl.tot<- as.integer(spam7$crl.tot)
 str(spam7)
 
 summary(spam7)
 
 set.seed(0)
 ind <- partition(1:nrow(spam7), p=c(0.5, 0.2, 0.3))
 
 spam.train <- data[ind$`1`,]
 spam.valid <- data[ind$`2`,]
 spam.test <- data[ind$`3`,] # Se guarda para el final

##############################################
## Ejemplo de uso de Naive Bayes, LDA y QDA

# Naive Bayes: Ajuste 
 
 naive1=naive_bayes(yesno~., data=spam.train) #gaussian default
 naive2=naive_bayes(yesno~., data=spam.train, usekernel = TRUE) #kernel
# Existen otros parametros que ajustar 
 
 naive1
 naive2

# ¿Como decidir entre kernel o gaussian? 
 
 hist(spam.train$crl.tot)
 hist(spam.train$dollar)
 hist(spam.train$bang)
 hist(spam.train$money)
 hist(spam.train$n000) 
 hist(spam.train$make)
 
 boxplot(spam.train$crl.tot~spam.train$yesno)
 boxplot(spam.train$dollar~spam.train$yesno)
 boxplot(spam.train$bang~spam.train$yesno)
 boxplot(spam.train$money~spam.train$yesno)
 boxplot(spam.train$n000~spam.train$yesno) 
 boxplot(spam.train$make~spam.train$yesno)
 
# Visualización
 
 plot(naive1, ask=TRUE)
 plot(naive2, ask=TRUE)
 
# Naive Bayes: Predicción 
 pred.naive1=predict(naive1, spam.valid) 
 head(pred.naive1)
 confusionMatrix(pred.naive1, spam.valid$yesno, mode="everything", positive="y")
 F_meas(pred.naive1, spam.valid$yesno, relevant="y")

 pred.prob.naive1=predict(naive1, spam.valid, type="prob") 
 round(head(pred.prob.naive1),4) 
 # se utiliza si queremos modificar el punto de corte,
 # o bien para reconocer los puntos difíciles de clasificar.
 # Se debe construir la matriz de confusión desde cero
 
 for(i in 1:19){
   aux.class.pred1=factor(ifelse(pred.prob.naive1[,2]>=i/20,"y","n"))
   print(table(spam.valid$yesno, aux.class.pred1))
   print(paste("prob corte=",i/20,"; F1=",
     round(F_meas(aux.class.pred1, spam.valid$yesno, relevant="y"),4),
     "; Accuracy=", round(Metrics::accuracy(aux.class.pred1, spam.valid$yesno), 4)) )
 }
 
 class.pred1=factor(ifelse(pred.prob.naive1[,2]>=0.05,"y","n"))
 confusionMatrix(class.pred1, spam.valid$yesno, mode="everything", positive="y")
 F_meas(class.pred1, spam.valid$yesno, relevant="y") 
 
# Predecir con el modelo 2 
 
 pred.naive2=predict(naive2, spam.valid) 
 head(pred.naive2)
 confusionMatrix(pred.naive2, spam.valid$yesno, mode="everything", positive="y")
 F_meas(pred.naive2, spam.valid$yesno, relevant="y")
 
 pred.prob.naive2=predict(naive2, spam.valid, type="prob") 
 round(head(pred.prob.naive2),4) 
 
 for(i in 1:19){
   aux.class.pred2=factor(ifelse(pred.prob.naive2[,2]>=i/20,"y","n"))
   print(table(spam.valid$yesno, aux.class.pred2))
   print(paste("prob corte=",i/20,"; F1=", round(F_meas(aux.class.pred2, spam.valid$yesno, relevant="y"),4),
               "; Accuracy=", round(Metrics::accuracy(aux.class.pred2, spam.valid$yesno), 4)) )
 }

 class.pred2=factor(ifelse(pred.prob.naive2[,2]>=0.05,"y","n"))
 confusionMatrix(class.pred2, spam.valid$yesno, mode="everything", positive="y")
 F_meas(class.pred2, spam.valid$yesno, relevant="y") 
 
##################################################  
## LDA: Ajuste
 lda1=lda(yesno~., data=spam.train) 
 lda2=lda(yesno~., data=spam.train, prior=c(0.5,0.5)) 

 lda1
 lda2
 
## LDA: Predicción  
 pred.lda1=predict(lda1, spam.valid)
 pred.lda2=predict(lda2, spam.valid)
 
 confusionMatrix(pred.lda1$class, spam.valid$yesno, mode="everything", positive="y")
 confusionMatrix(pred.lda2$class, spam.valid$yesno, mode="everything", positive="y")
 
 round(head(pred.lda1$posterior),4) 
 round(head(pred.lda2$posterior),4) 
 
 for(i in 5:19){
   aux.class.pred1=factor(ifelse(pred.lda1$posterior[,2]>=i/20,"y","n"))
   print(table(spam.valid$yesno, aux.class.pred1))
   print(paste("prob corte=",i/20,"; F1=", round(F_meas(aux.class.pred1, spam.valid$yesno, relevant="y"),4),
               "; Accuracy=", round(Metrics::accuracy(aux.class.pred1, spam.valid$yesno), 4)) )
 }
 
 class.lda1=factor(ifelse(pred.lda1$posterior[,2]>=0.3,"y","n"))
 confusionMatrix(class.lda1, spam.valid$yesno, mode="everything", positive="y")
 F_meas(class.lda1, spam.valid$yesno, relevant="y") 
  
 for(i in 6:19){
   aux.class.pred2=factor(ifelse(pred.lda2$posterior[,2]>=i/20,"y","n"))
   print(table(spam.valid$yesno, aux.class.pred2))
   print(paste("prob corte=",i/20,"; F1=", round(F_meas(aux.class.pred2, spam.valid$yesno, relevant="y"),4),
               "; Accuracy=", round(Metrics::accuracy(aux.class.pred2, spam.valid$yesno), 4)) )
 }
 
 class.lda2=factor(ifelse(pred.lda2$posterior[,2]>=0.4,"y","n"))
 confusionMatrix(class.lda2, spam.valid$yesno, mode="everything", positive="y")
 F_meas(class.lda2, spam.valid$yesno, relevant="y") 
 
 
##################################################  
## QDA: Ajuste
 qda1=qda(yesno~., data=spam.train) 
 qda2=qda(yesno~., data=spam.train, prior=c(0.5,0.5)) 
 
 ## QDA: Predicción  
 pred.qda1=predict(qda1, spam.valid)
 pred.qda2=predict(qda2, spam.valid)
 
 confusionMatrix(pred.qda1$class, spam.valid$yesno, mode="everything", positive="y")
 confusionMatrix(pred.qda2$class, spam.valid$yesno, mode="everything", positive="y")
 
 round(head(pred.qda1$posterior),4) 
 round(head(pred.qda2$posterior),4) 
 
 for(i in 1:19){
   aux.class.pred1=factor(ifelse(pred.qda1$posterior[,2]>=i/20,"y","n"))
   print(table(spam.valid$yesno, aux.class.pred1))
   print(paste("prob corte=",i/20,"; F1=", round(F_meas(aux.class.pred1, spam.valid$yesno, relevant="y"),4),
               "; Accuracy=", round(Metrics::accuracy(aux.class.pred1, spam.valid$yesno), 4)) )
 }
 
 class.qda1=factor(ifelse(pred.qda1$posterior[,2]>=0.05,"y","n"))
 confusionMatrix(class.qda1, spam.valid$yesno, mode="everything", positive="y")
 F_meas(class.qda1, spam.valid$yesno, relevant="y") 
 
 for(i in 1:19){
   aux.class.pred2=factor(ifelse(pred.qda2$posterior[,2]>=i/20,"y","n"))
   print(table(spam.valid$yesno, aux.class.pred2))
   print(paste("prob corte=",i/20,"; F1=", round(F_meas(aux.class.pred2, spam.valid$yesno, relevant="y"),4),
               "; Accuracy=", round(Metrics::accuracy(aux.class.pred2, spam.valid$yesno), 4)) )
 }
 
 class.qda2=factor(ifelse(pred.qda2$posterior[,2]>=0.05,"y","n"))
 confusionMatrix(class.qda2, spam.valid$yesno, mode="everything", positive="y")
 F_meas(class.qda2, spam.valid$yesno, relevant="y")  
 
 
######################################
## Resumen de Matrices de Confusión
 
 t(confusionMatrix(pred.naive1, spam.valid$yesno)$table)
 t(confusionMatrix(class.pred1, spam.valid$yesno)$table)
 
 t(confusionMatrix(pred.naive2, spam.valid$yesno)$table)
 t(confusionMatrix(class.pred2, spam.valid$yesno)$table)

 t(confusionMatrix(pred.lda1$class, spam.valid$yesno)$table)
 t(confusionMatrix(class.lda1, spam.valid$yesno)$table)
 
 t(confusionMatrix(pred.lda2$class, spam.valid$yesno)$table)
 t(confusionMatrix(class.lda2, spam.valid$yesno)$table)
 
 t(confusionMatrix(pred.qda1$class, spam.valid$yesno)$table)
 t(confusionMatrix(class.qda1, spam.valid$yesno)$table)
 
 t(confusionMatrix(pred.qda2$class, spam.valid$yesno)$table)
 t(confusionMatrix(class.qda2, spam.valid$yesno)$table)

## Naturalmente los modelos se pueden mejorar descartando variables no significativas 

 
##############################################################################
 
 faraway::vif(spam.train[,-7]) # No hay multicolinealidad
 
 names.models <- function(x){
   n=length(x)
   models=list()
   k=0
   for(i in 1:n){
     for(j in i:n){
       k=k+1
       models[[k]] = paste(x[i:j],sep="+")
     }
   }
   return(models)
 }
 
 modelos=names.models( x=names(spam.train)[-7] )
 modelos

## Naive Bayes 
  
 nb=list()
 res.nb=c()
 for(j in 1:length(modelos)){
  nb[[j]] <- train(x=spam.train[modelos[[j]]], y=spam.train$yesno, 
       trControl=trainControl(method="cv", number=5),
       method="naive_bayes" )
  res.nb=rbind(res.nb,  nb[[j]]$results[which.max(nb[[j]]$results$Accuracy),])
  print(nb[[j]]$results)
 }
 res.nb[which.max(res.nb$Accuracy),]
 modelos[which.max(res.nb$Accuracy)]
 
 names( nb[[which.max(res.nb$Accuracy)]] )
 plot(  nb[[which.max(res.nb$Accuracy)]]$finalModel, ask=TRUE ) 
 nb[[which.max(res.nb$Accuracy)]]

 pred.nb=predict(nb[[which.max(res.nb$Accuracy)]]$finalModel, spam.valid)
 confusionMatrix(pred.nb, spam.valid$yesno, mode="everything", positive="y")
 
# analizando el punto de corte 
 
 pred.prob.nb=predict(nb[[which.max(res.nb$Accuracy)]]$finalModel, spam.valid, type="prob") 
 round(head(pred.prob.nb),4) 
 
 for(i in 1:19){
   aux.class.pred1=factor(ifelse(pred.prob.nb[,2]>=i/20,"y","n"))
   print(table(spam.valid$yesno, aux.class.pred1))
   print(paste("prob corte=",i/20,"; F1=", round(F_meas(aux.class.pred1, spam.valid$yesno, relevant="y"),4),
               "; Accuracy=", round(Metrics::accuracy(aux.class.pred1, spam.valid$yesno), 4)) )
 }
 
 class.pred.nb=factor(ifelse(pred.prob.nb[,2]>=0.05,"y","n"))
 confusionMatrix(class.pred.nb, spam.valid$yesno, mode="everything", positive="y")

 
## LDA 
 
 lda0=list()
 res.lda0=c()
 for(j in 1:length(modelos)){
   lda0[[j]] <- train(x=spam.train[modelos[[j]]], y=spam.train$yesno, 
                    trControl=trainControl(method="cv", number=5),
                    method="lda" )
   res.lda0=rbind(res.lda0,  lda0[[j]]$results)
   print(lda0[[j]]$results)
 }
 lda0[[which.max(res.lda0$Accuracy)]]
 
 res.lda0[which.max(res.lda0$Accuracy),]
 modelos[which.max(res.lda0$Accuracy)]   # escogen las 6 variables no hay mejora
 confusionMatrix(pred.lda1$class, spam.valid$yesno, mode="everything", positive="y")
 
## QDA 
 
 qda0=list()
 res.qda0=c()
 for(j in 1:length(modelos)){
   qda0[[j]] <- train(x=spam.train[modelos[[j]]], y=spam.train$yesno, 
                      trControl=trainControl(method="cv", number=5),
                      method="qda" )
   res.qda0=rbind(res.qda0,  qda0[[j]]$results)
   print(qda0[[j]]$results)
 }
 res.qda0[which.max(res.qda0$Accuracy),]
 modelos[which.max(res.qda0$Accuracy)]   
 
 qda0.final=qda(yesno~dollar+bang+money+n000, data=spam.train) 
 pred.qda0=predict(qda0.final, spam.valid)
 
 sum(predict(qda0[[which.max(res.qda0$Accuracy)]], spam.valid)!=pred.qda0$class)
 confusionMatrix(pred.qda0$class, spam.valid$yesno, mode="everything", positive="y")
 
 # analizando el punto de corte 
 
 round(head(pred.qda0$posterior),4) 
 
 for(i in 1:19){
   aux.class.pred1=factor(ifelse(pred.qda0$posterior[,2]>=i/20,"y","n"))
   print(table(spam.valid$yesno, aux.class.pred1))
   print(paste("prob corte=",i/20,"; F1=", round(F_meas(aux.class.pred1, spam.valid$yesno, relevant="y"),4),
               "; Accuracy=", round(Metrics::accuracy(aux.class.pred1, spam.valid$yesno), 4)) )
 }
 
 class.pred.qda=factor(ifelse(pred.qda0$posterior[,2]>=0.05,"y","n"))
 confusionMatrix(class.pred.qda, spam.valid$yesno, mode="everything", positive="y")
 

# Bernoulli
 
 glm0=list()
 res.glm0=c()
 for(j in 1:length(modelos)){
   glm0[[j]] <- train(x=spam.train[modelos[[j]]], y=spam.train$yesno, 
                      trControl=trainControl(method="cv", number=5),
                      method="glm" )
   res.glm0=rbind(res.glm0,  glm0[[j]]$results)
   print(glm0[[j]]$results)
 }
 res.glm0[which.max(res.glm0$Accuracy),]
 modelos[which.max(res.glm0$Accuracy)]    
 glm0[[which.max(res.glm0$Accuracy)]]

 glm1=train(yesno~., data=spam.train, 
            trControl=trainControl(method="cv", number=5),
            method="glmStepAIC")
 glm1$results
 glm1$finalModel
 summary(glm1$finalModel)
 step(glm(yesno~., data=spam.train, family=binomial)) #igual a glm1$finalModel
 
 glm2=step(glm(yesno~., data=spam.train, family=binomial(link="probit")))
 glm3=step(glm(yesno~., data=spam.train, family=binomial(link="cloglog")))
 summary(glm2) 
 summary(glm3)

# Ejercicio: Buscar un mejor modelo
 
 class.glm0=predict(glm0[[which.max(res.glm0$Accuracy)]], spam.valid)
 pred.glm1=predict(glm1$finalModel, spam.valid, type="response")
 pred.glm2=predict(glm2, spam.valid, type="response")
 pred.glm3=predict(glm3, spam.valid, type="response")
 
 class.glm1=factor(ifelse(pred.glm1>=0.5, "y", "n"))
 class.glm2=factor(ifelse(pred.glm2>=0.5, "y", "n"))
 class.glm3=factor(ifelse(pred.glm3>=0.5, "y", "n"))
 
 confusionMatrix(class.glm0, spam.valid$yesno, mode="everything", positive="y")
 confusionMatrix(class.glm1, spam.valid$yesno, mode="everything", positive="y")
 confusionMatrix(class.glm2, spam.valid$yesno, mode="everything", positive="y")
 confusionMatrix(class.glm3, spam.valid$yesno, mode="everything", positive="y")
 
 modelos[which.max(res.glm0$Accuracy)] 
 prob.glm0=predict(glm(yesno~dollar+bang+money+n000+make, data=spam.train,
                       family=binomial), spam.valid, type="response")
   
 
 for(i in 4:19){
   aux.class.pred1=factor(ifelse(prob.glm0>=i/20,"y","n"))
   print(table(spam.valid$yesno, aux.class.pred1))
   print(paste("prob corte=",i/20,"; F1=", round(F_meas(aux.class.pred1, spam.valid$yesno, relevant="y"),4),
               "; Accuracy=", round(Metrics::accuracy(aux.class.pred1, spam.valid$yesno), 4)) )
 }
 class2.glm0=factor(ifelse(prob.glm0>=0.2,"y","n"))
 confusionMatrix(class2.glm0, spam.valid$yesno, mode="everything", positive="y")
 
 for(i in 4:19){
   aux.class.pred1=factor(ifelse(pred.glm1>=i/20,"y","n"))
   print(table(spam.valid$yesno, aux.class.pred1))
   print(paste("prob corte=",i/20,"; F1=", round(F_meas(aux.class.pred1, spam.valid$yesno, relevant="y"),4),
               "; Accuracy=", round(Metrics::accuracy(aux.class.pred1, spam.valid$yesno), 4)) )
 }
 class2.glm1=factor(ifelse(pred.glm1>=0.35,"y","n"))
 confusionMatrix(class2.glm1, spam.valid$yesno, mode="everything", positive="y")
 
 for(i in 4:19){
   aux.class.pred1=factor(ifelse(pred.glm2>=i/20,"y","n"))
   print(table(spam.valid$yesno, aux.class.pred1))
   print(paste("prob corte=",i/20,"; F1=", round(F_meas(aux.class.pred1, spam.valid$yesno, relevant="y"),4),
               "; Accuracy=", round(Metrics::accuracy(aux.class.pred1, spam.valid$yesno), 4)) )
 }
 class2.glm2=factor(ifelse(pred.glm2>=0.35,"y","n"))
 confusionMatrix(class2.glm2, spam.valid$yesno, mode="everything", positive="y")
 
 for(i in 5:19){
   aux.class.pred1=factor(ifelse(pred.glm3>=i/20,"y","n"))
   print(table(spam.valid$yesno, aux.class.pred1))
   print(paste("prob corte=",i/20,"; F1=", round(F_meas(aux.class.pred1, spam.valid$yesno, relevant="y"),4),
               "; Accuracy=", round(Metrics::accuracy(aux.class.pred1, spam.valid$yesno), 4)) )
 }
 class2.glm3=factor(ifelse(pred.glm3>=0.35,"y","n"))
 confusionMatrix(class2.glm3, spam.valid$yesno, mode="everything", positive="y")
 
##############################################################
### Resultados finales ajuste
 
 confusionMatrix(pred.nb, spam.valid$yesno, mode="everything", positive="y")$table
 confusionMatrix(pred.lda1$class, spam.valid$yesno, mode="everything", positive="y")$table
 confusionMatrix(pred.qda0$class, spam.valid$yesno, mode="everything", positive="y")$table
 confusionMatrix(class.glm0, spam.valid$yesno, mode="everything", positive="y")$table
 confusionMatrix(class.glm1, spam.valid$yesno, mode="everything", positive="y")$table
 confusionMatrix(class.glm2, spam.valid$yesno, mode="everything", positive="y")$table
 confusionMatrix(class.glm3, spam.valid$yesno, mode="everything", positive="y")$table
 
 accuracy(pred.nb, spam.valid$yesno)
 accuracy(pred.lda1$class, spam.valid$yesno)
 accuracy(pred.qda0$class, spam.valid$yesno)
 accuracy(class.glm0, spam.valid$yesno) # El mejor
 accuracy(class.glm1, spam.valid$yesno)
 accuracy(class.glm2, spam.valid$yesno)
 accuracy(class.glm3, spam.valid$yesno)
 
 F_meas(pred.nb, spam.valid$yesno, relevant="y")
 F_meas(pred.lda1$class, spam.valid$yesno, relevant="y")
 F_meas(pred.qda0$class, spam.valid$yesno, relevant="y")
 F_meas(class.glm0, spam.valid$yesno, relevant="y") # El mejor
 F_meas(class.glm1, spam.valid$yesno, relevant="y")
 F_meas(class.glm2, spam.valid$yesno, relevant="y")
 F_meas(class.glm3, spam.valid$yesno, relevant="y")
 
 F_meas(pred.nb, spam.valid$yesno, relevant="y", beta=2)
 F_meas(pred.lda1$class, spam.valid$yesno, relevant="y", beta=2)
 F_meas(pred.qda0$class, spam.valid$yesno, relevant="y", beta=2)
 F_meas(class.glm0, spam.valid$yesno, relevant="y", beta=2) # El mejor
 F_meas(class.glm1, spam.valid$yesno, relevant="y", beta=2)
 F_meas(class.glm2, spam.valid$yesno, relevant="y", beta=2)
 F_meas(class.glm3, spam.valid$yesno, relevant="y", beta=2)
 

### Mejor modelo modificando el punto de corte
 
 confusionMatrix(class.pred.nb, spam.valid$yesno, mode="everything", positive="y")$table
 confusionMatrix(class.lda1, spam.valid$yesno, mode="everything", positive="y")$table
 confusionMatrix(class.pred.qda, spam.valid$yesno, mode="everything", positive="y")$table
 confusionMatrix(class2.glm0, spam.valid$yesno, mode="everything", positive="y")$table
 confusionMatrix(class2.glm1, spam.valid$yesno, mode="everything", positive="y")$table
 confusionMatrix(class2.glm2, spam.valid$yesno, mode="everything", positive="y")$table
 confusionMatrix(class2.glm3, spam.valid$yesno, mode="everything", positive="y")$table
 
 accuracy(class.pred.nb, spam.valid$yesno) # El mejor
 accuracy(class.lda1, spam.valid$yesno)
 accuracy(class.pred.qda, spam.valid$yesno)
 accuracy(class2.glm0, spam.valid$yesno) 
 accuracy(class2.glm1, spam.valid$yesno)
 accuracy(class2.glm2, spam.valid$yesno)
 accuracy(class2.glm3, spam.valid$yesno)
  
 F_meas(class.pred.nb,spam.valid$yesno, relevant="y") # El mejor
 F_meas(class.lda1, spam.valid$yesno, relevant="y")
 F_meas(class.pred.qda, spam.valid$yesno, relevant="y")
 F_meas(class2.glm0, spam.valid$yesno, relevant="y") 
 F_meas(class2.glm1, spam.valid$yesno, relevant="y")
 F_meas(class2.glm2, spam.valid$yesno, relevant="y")
 F_meas(class2.glm3, spam.valid$yesno, relevant="y")
 
 F_meas(class.pred.nb,spam.valid$yesno, relevant="y", beta=2) 
 F_meas(class.lda1, spam.valid$yesno, relevant="y", beta=2)
 F_meas(class.pred.qda, spam.valid$yesno, relevant="y", beta=2)
 F_meas(class2.glm0, spam.valid$yesno, relevant="y", beta=2) # El mejor
 F_meas(class2.glm1, spam.valid$yesno, relevant="y", beta=2)
 F_meas(class2.glm2, spam.valid$yesno, relevant="y", beta=2)
 F_meas(class2.glm3, spam.valid$yesno, relevant="y", beta=2)
 
#################################################################################
##  Evaluación final del modelo (No se debe usar para seleccionar, solo validar)
 
 modelos[which.max(res.nb$Accuracy)]
 modelos[which.max(res.glm0$Accuracy)]    
 
 test.nb=naive_bayes(yesno~crl.tot+dollar+bang+money, data=rbind(spam.train, spam.valid), usekernel = TRUE) 
 test.glm=glm(yesno~dollar+bang+money+n000+make, data=rbind(spam.train, spam.valid), family=binomial) 

 pred1.test.nb=predict(nb[[which.max(res.nb$Accuracy)]]$finalModel, spam.test, type="prob")
 pred2.test.nb=predict(test.nb, spam.test, type="prob")
 
 class1.test.nb=factor(ifelse(pred1.test.nb[,2]>=0.05,"y","n"))
 class2.test.nb=factor(ifelse(pred2.test.nb[,2]>=0.05,"y","n"))
 
 pred1.test.glm=predict(glm(yesno~dollar+bang+money+n000+make, data=spam.train,
                            family=binomial), spam.test, type="response")
 pred2.test.glm=predict(test.glm, spam.test, response="response")
 
 class1.test.glm=factor(ifelse(pred1.test.glm>=0.2,"y","n"))
 class2.test.glm=factor(ifelse(pred2.test.glm>=0.2,"y","n"))
 
 confusionMatrix(class1.test.nb, spam.test$yesno, mode="everything", positive="y")
 confusionMatrix(class1.test.glm, spam.test$yesno, mode="everything", positive="y")
 
 confusionMatrix(class2.test.nb, spam.test$yesno, mode="everything", positive="y")
 confusionMatrix(class2.test.glm, spam.test$yesno, mode="everything", positive="y")
 